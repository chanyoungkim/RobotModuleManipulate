

#ifndef _MAP_READ_H_
#define _MAP_READ_H_

int connectToClient();
void *netReadThreadFunc(void);
int mapread(int intX[], int inY[]);

#endif

