/*
 *
 *
 */

#ifndef	_STEREO_H_
#define	_STEREO_H_

#include <pxa_lib.h>
#include <pxa_camera_zl.h>

#include <math.h>

int stereo(int* boundS, int* boundC, int* heightS, int* heightC, int* cordinate);

#endif

