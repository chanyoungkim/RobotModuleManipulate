#include "module/communication/communication.h"

void* receiveMsg(void) {
	
}